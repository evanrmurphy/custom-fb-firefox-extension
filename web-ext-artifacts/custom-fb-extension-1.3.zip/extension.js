// For debugging
//
//function testFn() { alert(getReactionsCountTextEls().map(el => el.innerText)); }
//setInterval(testFn, 5000);
